/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eps;

/**
 *
 * @author VARSHA
 */
public class payroll {
    //private final int idemployee;
    //private final String ename,dob,gender,desigination,salary;
    private int idemployee; 
    private int salary;
    private String ename,dob,gender,desigination,epassword;
    private String string;
    public payroll(int idemployee,String ename,String dob,String gender,String desigination,int salary,String epassword)
    {
        this.idemployee=idemployee;
        this.ename=ename;
        this.dob=dob;
        this.gender=gender;
       this.desigination=desigination;
        this.salary=salary;
        this.epassword=epassword;
    }

    

    public int getidemployee(){
        
        return idemployee;
    }
    public String getename(){
      
        return ename;
    }
    public String getdob(){
     
        return dob;
    }
    public String getgender(){
      
        return gender;
    }
    public String getdesigination(){
      
        return desigination;
    }
    public int getsalary(){
        
        return salary;
    }
    public String epassword(){
      
        return epassword;
    }

    

        
    }


    


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eps;

/**
 *
 * @author VARSHA
 */
class employee {
    private int idemployee; 
    private int salary;
    private String ename,dob,gender,desigination,epassword;
    public employee(int idemployee, String ename,String dob,String gender,String desigination,int salary,String epassword)
    {
        this.idemployee=idemployee;
        this.ename=ename;
        this.dob=dob;
        this.gender=gender;
       this.desigination=desigination;
        this.salary=salary;
        this.epassword=epassword;
    }

    employee(int aInt, String string, String string0, int aInt0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   

    public int getidemployee(){
        
        return idemployee;
    }
    public String getename(){
      
        return ename;
    }
    public String getdob(){
     
        return dob;
    }
    public String getgender(){
      
        return gender;
    }
    public String getdesigination(){
      
        return desigination;
    }
    public int getsalary(){
        
        return salary;
    }
    
    public String epassword(){
      
        return epassword;
    }

    Object getepassword() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   // Object getidemployee() {
     //   throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    //}

    

    

    
}

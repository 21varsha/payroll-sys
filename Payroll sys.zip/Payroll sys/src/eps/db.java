/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eps;
import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author VARSHA
 */
public class db {
    public static void main(String args[]) {
        Connection conn=null;
        
        try{
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/payroll","root","varsha");
            if(conn!=null)
            {
                System.out.println("Connected to database success");
            }
           }catch(Exception e)
           {
                System.out.println("NotConnected to database");
           }
           }
    
}

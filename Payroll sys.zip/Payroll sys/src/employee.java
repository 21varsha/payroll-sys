/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author VARSHA
 */
public class employee {
    private final int idemployee;
    private final String ename,dob,gender,desigination,salary;
    
    private employee(int idemployee,String ename,String dob,String gender,String desigination,String salary)
    {
        this.idemployee=idemployee;
        this.ename=ename;
        this.dob=dob;
        this.gender=gender;
        this.desigination=desigination;
        this.salary=salary;
    }
    public int getidemployee(){
        return idemployee;
    }
    public String getename(){
        return ename;
    }
    public String getdob(){
        return dob;
    }
    public String getgender(){
        return gender;
    }
    public String getdesigination(){
        return desigination;
    }
    public String getsalary(){
        return salary;
    }
    
    
}
